package me.purple.client.core;

import me.purple.client.gui.ClickGUI;
import me.purple.client.module.ModuleManager;
import me.purple.client.event.EventManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(modid = PurpleClient.MODID, name = PurpleClient.NAME, version = PurpleClient.VERSION)
public class PurpleClient {

    public static final String MODID   = "purpleclient";
    public static final String NAME    = "Purple Client";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER  = LogManager.getLogger(NAME);

    private static PurpleClient instance;
    private ModuleManager moduleManager;
    private EventManager  eventManager;
    private ClickGUI      clickGUI;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        instance = this;
        LOGGER.info("Purple Client Pre-Initializing...");
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        LOGGER.info("Purple Client Initializing...");
        eventManager  = new EventManager();
        moduleManager = new ModuleManager();
        clickGUI      = new ClickGUI();
        moduleManager.init();
        LOGGER.info("Purple Client Initialized! {} modules loaded.", moduleManager.getModules().size());
    }

    public static PurpleClient getInstance() { return instance; }
    public ModuleManager getModuleManager()  { return moduleManager; }
    public EventManager  getEventManager()   { return eventManager; }
    public ClickGUI      getClickGUI()       { return clickGUI; }
}
