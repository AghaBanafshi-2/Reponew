package me.purple.client.module;

public enum ModuleCategory {
    HUD("HUD"),
    RENDER("Render"),
    MOVEMENT("Movement"),
    COMBAT("Combat"),
    MISC("Misc");

    private final String displayName;
    ModuleCategory(String n) { this.displayName = n; }
    public String getDisplayName() { return displayName; }
}
