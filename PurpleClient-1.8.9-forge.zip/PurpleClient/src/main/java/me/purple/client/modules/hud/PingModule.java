package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import java.awt.Color;

public class PingModule extends Module {
    public PingModule() {
        super("Ping", "Server latency in ms", ModuleCategory.HUD);
        this.width = 65; this.height = 14;
    }

    @Override
    public void onRender() {
        Minecraft mc = Minecraft.getMinecraft();
        int ping = 0;
        if (mc.thePlayer != null && mc.getNetHandler() != null) {
            NetworkPlayerInfo info = mc.getNetHandler()
                    .getPlayerInfo(mc.thePlayer.getUniqueID());
            if (info != null) ping = info.getResponseTime();
        }

        String text = "Ping: " + ping + "ms";
        int w = RenderUtil.getTextWidth(text) + 8;
        this.width = w;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);

        Color pingColor;
        if      (ping <  80) pingColor = new Color(100, 255, 100);
        else if (ping < 150) pingColor = RenderUtil.PURPLE_ACCENT;
        else if (ping < 250) pingColor = new Color(255, 200, 50);
        else                 pingColor = new Color(255, 80, 80);

        RenderUtil.drawText("Ping: ", x+4, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(ping + "ms",
                x+4+RenderUtil.getTextWidth("Ping: "), y+3, pingColor, false);
    }
}
