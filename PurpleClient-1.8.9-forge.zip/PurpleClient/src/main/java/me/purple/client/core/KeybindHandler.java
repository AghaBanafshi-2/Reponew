package me.purple.client.core;

import me.purple.client.gui.ClickGUI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class KeybindHandler {
    private final KeyBinding openGui = new KeyBinding(
            "Open Purple Client GUI", Keyboard.KEY_RSHIFT, "Purple Client");

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (openGui.isPressed()) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.theWorld != null) {
                mc.displayGuiScreen(PurpleClient.getInstance().getClickGUI());
            }
        }
    }

    public KeyBinding getBinding() { return openGui; }
}
