package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.awt.Color;

public class FPSModule extends Module {
    private int fps = 0;

    public FPSModule() {
        super("FPS", "Shows current FPS", ModuleCategory.HUD);
        this.width  = 50;
        this.height = 14;
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            fps = Minecraft.getDebugFPS();
        }
    }

    @Override
    public void onRender() {
        String text = "FPS: " + fps;
        int w = RenderUtil.getTextWidth(text) + 8;
        this.width = w;

        // Background pill
        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);

        // FPS color based on value
        Color fpsColor;
        if      (fps >= 100) fpsColor = new Color(100, 255, 100);
        else if (fps >= 60)  fpsColor = RenderUtil.PURPLE_ACCENT;
        else if (fps >= 30)  fpsColor = new Color(255, 200, 50);
        else                 fpsColor = new Color(255, 80, 80);

        RenderUtil.drawText("FPS: ", x + 4, y + 3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(String.valueOf(fps),
                x + 4 + RenderUtil.getTextWidth("FPS: "), y + 3, fpsColor, false);
    }
}
