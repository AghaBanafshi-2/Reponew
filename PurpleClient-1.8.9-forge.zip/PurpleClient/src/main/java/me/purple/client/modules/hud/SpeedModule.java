package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.awt.Color;

public class SpeedModule extends Module {
    private double speed = 0;

    public SpeedModule() {
        super("Speed", "Current movement speed (BPS)", ModuleCategory.HUD);
        this.width = 80; this.height = 14;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;
        double dx = p.posX - p.prevPosX;
        double dz = p.posZ - p.prevPosZ;
        speed = Math.sqrt(dx*dx + dz*dz) * 20; // blocks per second
    }

    @Override
    public void onRender() {
        String bps = String.format("%.2f", speed) + " BPS";
        int w = RenderUtil.getTextWidth("Speed: " + bps) + 8;
        this.width = w;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);
        RenderUtil.drawText("Speed: ", x+4, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(bps,
                x+4+RenderUtil.getTextWidth("Speed: "), y+3,
                RenderUtil.PURPLE_ACCENT, false);
    }
}
