package me.purple.client.events;

import me.purple.client.core.PurpleClient;
import me.purple.client.gui.ClickGUI;
import me.purple.client.modules.hud.CPSModule;
import me.purple.client.modules.hud.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class EventManager {

    private static final Minecraft mc = Minecraft.getMinecraft();

    // ── HUD Render ────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.currentScreen != null) return; // hide HUD while GUI is open

        for (HudModule m : PurpleClient.getHudModules()) {
            if (m.isEnabled()) m.render(event.partialTicks);
        }
    }

    // ── Tick ──────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        for (HudModule m : PurpleClient.getHudModules()) {
            if (m.isEnabled()) m.onUpdate();
        }
    }

    // ── Mouse (CPS tracking) ─────────────────────────────────────────────────

    @SubscribeEvent
    public void onMouse(MouseEvent event) {
        if (event.button == -1 || !event.buttonstate) return;
        for (HudModule m : PurpleClient.getHudModules()) {
            if (m instanceof CPSModule) {
                ((CPSModule) m).registerClick(event.button);
            }
        }
    }

    // ── Keyboard (open GUI with Right-Shift) ─────────────────────────────────

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)) {
            if (mc.currentScreen == null) {
                mc.displayGuiScreen(PurpleClient.getClickGUI());
            }
        }
    }
}
