package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ClockModule extends Module {
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss");

    public ClockModule() {
        super("Clock", "Current real-world time", ModuleCategory.HUD);
        this.width = 70; this.height = 14;
    }

    @Override
    public void onRender() {
        String time = fmt.format(new Date());
        int w = RenderUtil.getTextWidth("⏰ " + time) + 8;
        this.width = w;
        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);
        RenderUtil.drawText("⏰ ", x+4, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(time,
                x+4+RenderUtil.getTextWidth("⏰ "), y+3,
                RenderUtil.PURPLE_ACCENT, false);
    }
}
