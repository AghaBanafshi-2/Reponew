package me.purple.client.module;

import me.purple.client.modules.hud.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // ── HUD ───────────────────────────────────────────
        register(new FPSModule(),         10, 10);
        register(new CPSModule(),         10, 28);
        register(new KeystrokesModule(),  10, 46);
        register(new CoordinatesModule(), 10, 108);
        register(new SpeedModule(),       10, 126);
        register(new PingModule(),        10, 144);
        register(new CompassModule(),     10, 162);
        register(new ClockModule(),       10, 180);
        register(new ArmorStatusModule(), 200, 10);
        register(new PotionStatusModule(),200, 70);
        register(new HungerModule(),      200, 150);
    }

    private void register(Module m, int x, int y) {
        m.setX(x);
        m.setY(y);
        m.toggle(); // enable by default
        modules.add(m);
    }

    public List<Module> getModules() { return modules; }

    public Module getByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }
}
