package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import java.awt.Color;

public class HungerModule extends Module {
    public HungerModule() {
        super("Hunger", "Food level display", ModuleCategory.HUD);
        this.width = 80; this.height = 14;
    }

    @Override
    public void onRender() {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;

        int food = p.getFoodStats().getFoodLevel();
        float sat  = p.getFoodStats().getSaturationLevel();

        String text = "🍖 " + food + "/20";
        int w = RenderUtil.getTextWidth(text) + 8;
        this.width = w;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);

        Color foodColor;
        if      (food >= 16) foodColor = new Color(100, 255, 100);
        else if (food >= 8)  foodColor = new Color(255, 200, 50);
        else                 foodColor = new Color(255, 80, 80);

        RenderUtil.drawText("Food: ", x+4, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(food + "/20",
                x+4+RenderUtil.getTextWidth("Food: "), y+3, foodColor, false);
    }
}
