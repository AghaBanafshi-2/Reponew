package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import java.awt.Color;

public class KeystrokesModule extends Module {
    // Key states
    private boolean w, a, s, d, space;

    public KeystrokesModule() {
        super("Keystrokes", "Shows pressed keys", ModuleCategory.HUD);
        this.width  = 68;
        this.height = 54;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getMinecraft();
        w     = mc.gameSettings.keyBindForward.isKeyDown();
        a     = mc.gameSettings.keyBindLeft.isKeyDown();
        s     = mc.gameSettings.keyBindBack.isKeyDown();
        d     = mc.gameSettings.keyBindRight.isKeyDown();
        space = mc.gameSettings.keyBindJump.isKeyDown();
    }

    @Override
    public void onRender() {
        // Draw WASD + Space layout
        //   [W]
        // [A][S][D]
        // [  SPACE  ]
        int kw = 20, kh = 16, gap = 2;

        drawKey("W", x + kw + gap, y,           w);
        drawKey("A", x,            y + kh + gap, a);
        drawKey("S", x + kw + gap, y + kh + gap, s);
        drawKey("D", x+(kw+gap)*2, y + kh + gap, d);
        // Space bar full width
        drawSpaceKey(x, y + (kh+gap)*2, (kw+gap)*3-gap, kh, space);
    }

    private void drawKey(String label, int kx, int ky, boolean pressed) {
        int kw = 20, kh = 16;
        Color bg  = pressed ? RenderUtil.PURPLE_PRIMARY : RenderUtil.BG_COLOR;
        Color text= pressed ? Color.WHITE : new Color(180,120,255);
        RenderUtil.drawRect(kx, ky, kw, kh, bg);
        RenderUtil.drawBorder(kx, ky, kw, kh, 1, RenderUtil.PURPLE_SECONDARY);
        int tx = kx + (kw - RenderUtil.getTextWidth(label)) / 2;
        RenderUtil.drawText(label, tx, ky + 4, text, false);
    }

    private void drawSpaceKey(int kx,int ky,int kw,int kh,boolean pressed){
        Color bg  = pressed ? RenderUtil.PURPLE_PRIMARY : RenderUtil.BG_COLOR;
        RenderUtil.drawRect(kx, ky, kw, kh, bg);
        RenderUtil.drawBorder(kx, ky, kw, kh, 1, RenderUtil.PURPLE_SECONDARY);
    }
}
