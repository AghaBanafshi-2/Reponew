package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import java.awt.Color;

public class CoordinatesModule extends Module {
    public CoordinatesModule() {
        super("Coordinates", "Shows XYZ position", ModuleCategory.HUD);
        this.width = 120; this.height = 34;
    }

    @Override
    public void onRender() {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;

        int px = (int) p.posX;
        int py = (int) p.posY;
        int pz = (int) p.posZ;

        String xStr = "X: " + px;
        String yStr = "Y: " + py;
        String zStr = "Z: " + pz;
        int w = Math.max(RenderUtil.getTextWidth(xStr + "  " + yStr + "  " + zStr) + 10, 100);
        this.width = w;
        this.height = 22;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);

        // X=red tint, Y=green tint, Z=blue tint (like F3)
        int cx = x + 4;
        RenderUtil.drawText(xStr, cx, y+7, new Color(255, 120, 120), false);
        cx += RenderUtil.getTextWidth(xStr) + 6;
        RenderUtil.drawText(yStr, cx, y+7, new Color(120, 255, 120), false);
        cx += RenderUtil.getTextWidth(yStr) + 6;
        RenderUtil.drawText(zStr, cx, y+7, new Color(120, 180, 255), false);
    }
}
