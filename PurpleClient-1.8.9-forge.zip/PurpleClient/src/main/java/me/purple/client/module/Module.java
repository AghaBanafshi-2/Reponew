package me.purple.client.module;

import me.purple.client.core.PurpleClient;
import java.awt.Color;

public abstract class Module {
    protected String name;
    protected String description;
    protected ModuleCategory category;
    protected boolean enabled = false;
    protected int x, y;
    protected int width = 80, height = 20;

    public Module(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void onEnable()  {}
    public void onDisable() {}
    public abstract void onRender();

    public void toggle() {
        enabled = !enabled;
        if (enabled) { onEnable();  PurpleClient.getInstance().getEventManager().register(this); }
        else          { onDisable(); PurpleClient.getInstance().getEventManager().unregister(this); }
    }

    // ── Getters / Setters ──────────────────────────────────
    public String          getName()        { return name; }
    public String          getDescription() { return description; }
    public ModuleCategory  getCategory()    { return category; }
    public boolean         isEnabled()      { return enabled; }
    public int getX()  { return x; }  public void setX(int x)  { this.x=x; }
    public int getY()  { return y; }  public void setY(int y)  { this.y=y; }
    public int getWidth()  { return width; }
    public int getHeight() { return height; }
}
