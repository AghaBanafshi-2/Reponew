package me.purple.client.event;
import net.minecraftforge.common.MinecraftForge;
public class EventManager {
    public void register(Object o)   { MinecraftForge.EVENT_BUS.register(o); }
    public void unregister(Object o) { MinecraftForge.EVENT_BUS.unregister(o); }
}
