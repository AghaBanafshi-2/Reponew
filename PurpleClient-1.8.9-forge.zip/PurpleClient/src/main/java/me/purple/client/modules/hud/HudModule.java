package me.purple.client.modules.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

import java.awt.*;

public abstract class HudModule extends Gui {

    protected static final Minecraft mc = Minecraft.getMinecraft();

    // Purple Client color palette
    public static final int COLOR_BG        = new Color(20, 10, 35, 180).getRGB();
    public static final int COLOR_BORDER     = new Color(130, 50, 220, 220).getRGB();
    public static final int COLOR_TEXT       = new Color(255, 255, 255, 255).getRGB();
    public static final int COLOR_TEXT_DIM   = new Color(180, 130, 255, 200).getRGB();
    public static final int COLOR_ACCENT     = new Color(160, 80, 255, 255).getRGB();
    public static final int COLOR_GLOW       = new Color(100, 40, 200, 100).getRGB();

    private String name;
    private boolean enabled;
    private int x, y;
    private int width, height;

    // For drag support in GUI
    private boolean dragging;
    private int dragOffsetX, dragOffsetY;

    public HudModule(String name, int defaultX, int defaultY) {
        this.name   = name;
        this.enabled = true;
        this.x = defaultX;
        this.y = defaultY;
    }

    /** Draw the module on the HUD. */
    public abstract void render(float partialTicks);

    /** Called every game tick. */
    public void onUpdate() {}

    // ── helpers ──────────────────────────────────────────────────────────────

    /** Draw a rounded-rectangle background with a purple border. */
    protected void drawModuleBackground(int x, int y, int w, int h) {
        // Glow / shadow layer
        drawRect(x - 1, y - 1, x + w + 1, y + h + 1, COLOR_GLOW);
        // Main background
        drawRect(x, y, x + w, y + h, COLOR_BG);
        // 1-px border top / bottom
        drawRect(x, y, x + w, y + 1, COLOR_BORDER);
        drawRect(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        // 1-px border left / right
        drawRect(x, y, x + 1, y + h, COLOR_BORDER);
        drawRect(x + w - 1, y, x + w, y + h, COLOR_BORDER);
    }

    protected FontRenderer getFontRenderer() {
        return mc.fontRendererObj;
    }

    protected void drawText(String text, int x, int y, int color) {
        getFontRenderer().drawStringWithShadow(text, x, y, color);
    }

    protected int textWidth(String text) {
        return getFontRenderer().getStringWidth(text);
    }

    // ── drag support ─────────────────────────────────────────────────────────

    public boolean mousePressed(int mouseX, int mouseY, int button) {
        if (button == 0 && mouseX >= x && mouseX <= x + width
                        && mouseY >= y && mouseY <= y + height) {
            dragging    = true;
            dragOffsetX = mouseX - x;
            dragOffsetY = mouseY - y;
            return true;
        }
        return false;
    }

    public void mouseReleased() { dragging = false; }

    public void mouseDragged(int mouseX, int mouseY) {
        if (dragging) {
            x = mouseX - dragOffsetX;
            y = mouseY - dragOffsetY;
        }
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= x && mouseX <= x + width
            && mouseY >= y && mouseY <= y + height;
    }

    // ── getters / setters ────────────────────────────────────────────────────

    public String  getName()    { return name; }
    public boolean isEnabled()  { return enabled; }
    public void    setEnabled(boolean e) { this.enabled = e; }
    public int     getX()       { return x; }
    public int     getY()       { return y; }
    public void    setX(int x)  { this.x = x; }
    public void    setY(int y)  { this.y = y; }
    public int     getWidth()   { return width; }
    public int     getHeight()  { return height; }
    public void    setWidth(int w)  { this.width  = w; }
    public void    setHeight(int h) { this.height = h; }
}
