package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PotionStatusModule extends Module {
    public PotionStatusModule() {
        super("Potions", "Active potion effects", ModuleCategory.HUD);
        this.width = 100; this.height = 14;
    }

    @Override
    public void onRender() {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;

        Collection<PotionEffect> effects = p.getActivePotionEffects();
        if (effects.isEmpty()) return;

        List<PotionEffect> list = new ArrayList<>(effects);
        int h = list.size() * 12 + 4;
        this.height = h;

        RenderUtil.drawRect(x, y, width, h, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, width, h, 1, RenderUtil.PURPLE_PRIMARY);

        for (int i = 0; i < list.size(); i++) {
            PotionEffect effect = list.get(i);
            Potion potion = Potion.potionTypes[effect.getPotionID()];
            int ry = y + 2 + i * 12;

            // Duration in seconds
            int secs = effect.getDuration() / 20;
            String time = secs > 60
                ? (secs/60) + "m" + (secs%60) + "s"
                : secs + "s";

            String name = potion.getName().replace("potion.effect.", "");
            name = name.substring(0,1).toUpperCase() + name.substring(1);
            int amp = effect.getAmplifier() + 1;
            String label = name + (amp > 1 ? " " + amp : "") + " §r" + time;

            // Color based on beneficial/harmful
            Color c = potion.isBadEffect()
                ? new Color(255, 120, 120)
                : new Color(160, 255, 160);

            RenderUtil.drawText("●", x+3, ry+2, c, false);
            RenderUtil.drawText(name + (amp>1?" "+amp:""), x+13, ry+2,
                    RenderUtil.PURPLE_ACCENT, false);
            String timeStr = time;
            RenderUtil.drawText(timeStr,
                    x + width - RenderUtil.getTextWidth(timeStr) - 4, ry+2,
                    new Color(180,180,180), false);
        }
    }
}
