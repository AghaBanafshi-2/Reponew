package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import java.awt.Color;

public class CompassModule extends Module {
    private static final String[] DIRS = {"N","NE","E","SE","S","SW","W","NW"};

    public CompassModule() {
        super("Compass", "Facing direction", ModuleCategory.HUD);
        this.width = 60; this.height = 14;
    }

    @Override
    public void onRender() {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;

        float yaw = p.rotationYaw % 360;
        if (yaw < 0) yaw += 360;
        int idx = (int)((yaw + 22.5f) / 45f) % 8;
        String dir = DIRS[idx];

        String text = "◈ " + dir + " (" + (int)yaw + "°)";
        int w = RenderUtil.getTextWidth(text) + 8;
        this.width = w;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);
        RenderUtil.drawText("◈ ", x+4, y+3, RenderUtil.PURPLE_PRIMARY, false);
        RenderUtil.drawText(dir,
                x+4+RenderUtil.getTextWidth("◈ "), y+3,
                RenderUtil.PURPLE_ACCENT, false);
        RenderUtil.drawText(" (" + (int)yaw + "°)",
                x+4+RenderUtil.getTextWidth("◈ "+dir), y+3,
                new Color(160,130,200), false);
    }
}
