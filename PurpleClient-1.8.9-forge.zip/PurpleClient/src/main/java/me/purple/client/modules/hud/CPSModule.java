package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Deque;

public class CPSModule extends Module {
    private final Deque<Long> leftClicks  = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean leftWasDown  = false;
    private boolean rightWasDown = false;

    public CPSModule() {
        super("CPS", "Clicks Per Second", ModuleCategory.HUD);
        this.width  = 75;
        this.height = 14;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;

        long now = System.currentTimeMillis();

        boolean leftDown  = Mouse.isButtonDown(0);
        boolean rightDown = Mouse.isButtonDown(1);

        if (leftDown  && !leftWasDown)  leftClicks.addLast(now);
        if (rightDown && !rightWasDown) rightClicks.addLast(now);

        leftWasDown  = leftDown;
        rightWasDown = rightDown;

        // Keep only last 1 second
        leftClicks .removeIf(t -> now - t > 1000);
        rightClicks.removeIf(t -> now - t > 1000);
    }

    @Override
    public void onRender() {
        int lCps = leftClicks.size();
        int rCps = rightClicks.size();

        String text  = "L: " + lCps + "  R: " + rCps;
        int w = RenderUtil.getTextWidth(text) + 8;
        this.width = w;

        RenderUtil.drawRect(x, y, w, height, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, w, height, 1, RenderUtil.PURPLE_PRIMARY);

        RenderUtil.drawText("L:", x+4, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(String.valueOf(lCps),
                x+4+RenderUtil.getTextWidth("L:"), y+3,
                new Color(200,150,255), false);

        int offset = x+4+RenderUtil.getTextWidth("L: "+lCps+"  ");
        RenderUtil.drawText("R:", offset, y+3, RenderUtil.PURPLE_SECONDARY, false);
        RenderUtil.drawText(String.valueOf(rCps),
                offset+RenderUtil.getTextWidth("R:"), y+3,
                new Color(200,150,255), false);
    }
}
