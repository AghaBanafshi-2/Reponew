package me.purple.client.gui;

import me.purple.client.core.PurpleClient;
import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.awt.Color;
import java.io.IOException;
import java.util.*;

public class ClickGUI extends GuiScreen {

    // ── Category panels ──────────────────────────────────────────────
    private final List<CategoryPanel> panels = new ArrayList<>();
    private static final int PANEL_W   = 110;
    private static final int HEADER_H  = 18;
    private static final int MODULE_H  = 16;
    private static final int PANEL_GAP = 8;

    // ── Drag state ───────────────────────────────────────────────────
    private Module dragging      = null;
    private int    dragOffX      = 0;
    private int    dragOffY      = 0;
    private CategoryPanel draggingPanel = null;
    private int    panelDragOffX = 0;
    private int    panelDragOffY = 0;

    public ClickGUI() {
        int startX = 20;
        for (ModuleCategory cat : ModuleCategory.values()) {
            panels.add(new CategoryPanel(cat, startX, 20));
            startX += PANEL_W + PANEL_GAP;
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        // Dim background
        drawRect(0, 0, this.width, this.height, new Color(0, 0, 0, 120).getRGB());

        // Title
        String title = "✦ Purple Client";
        drawCenteredString(mc.fontRendererObj, title,
                this.width / 2, 4, RenderUtil.PURPLE_ACCENT.getRGB());

        // Panels
        for (CategoryPanel p : panels) p.draw(mx, my);

        // Drag ghost for HUD elements
        if (dragging != null) {
            dragging.setX(mx - dragOffX);
            dragging.setY(my - dragOffY);
        }
        if (draggingPanel != null) {
            draggingPanel.x = mx - panelDragOffX;
            draggingPanel.y = my - panelDragOffY;
        }

        super.drawScreen(mx, my, pt);
    }

    @Override
    public void mouseClicked(int mx, int my, int btn) throws IOException {
        for (CategoryPanel p : panels) {
            // Click header → toggle collapse
            if (mx >= p.x && mx <= p.x + PANEL_W &&
                my >= p.y && my <= p.y + HEADER_H) {
                if (btn == 0) {
                    panelDragOffX = mx - p.x;
                    panelDragOffY = my - p.y;
                    draggingPanel = p;
                } else if (btn == 1) {
                    p.collapsed = !p.collapsed;
                }
                return;
            }
            if (p.collapsed) continue;

            // Click module row
            List<Module> mods = getModulesForCategory(p.category);
            for (int i = 0; i < mods.size(); i++) {
                Module m = mods.get(i);
                int rowY = p.y + HEADER_H + i * MODULE_H;
                if (mx >= p.x && mx <= p.x + PANEL_W &&
                    my >= rowY && my <= rowY + MODULE_H) {
                    if (btn == 0) m.toggle();
                    return;
                }
            }
        }
        super.mouseClicked(mx, my, btn);
    }

    @Override
    public void mouseReleased(int mx, int my, int btn) {
        dragging      = null;
        draggingPanel = null;
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) mc.displayGuiScreen(null);
    }

    // ── Helper ───────────────────────────────────────────────────────
    private List<Module> getModulesForCategory(ModuleCategory cat) {
        List<Module> result = new ArrayList<>();
        for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
            if (m.getCategory() == cat) result.add(m);
        }
        return result;
    }

    // ── Inner class: panel ────────────────────────────────────────────
    class CategoryPanel {
        ModuleCategory category;
        int x, y;
        boolean collapsed = false;

        CategoryPanel(ModuleCategory cat, int x, int y) {
            this.category = cat;
            this.x = x;
            this.y = y;
        }

        void draw(int mx, int my) {
            List<Module> mods = getModulesForCategory(category);
            int totalH = HEADER_H + (collapsed ? 0 : mods.size() * MODULE_H);

            // Panel background
            RenderUtil.drawRect(x, y, PANEL_W, totalH, RenderUtil.BG_COLOR);

            // Header gradient
            RenderUtil.drawGradientRect(x, y, PANEL_W, HEADER_H,
                    RenderUtil.PURPLE_DARK, RenderUtil.PURPLE_PRIMARY);
            RenderUtil.drawBorder(x, y, PANEL_W, totalH, 1, RenderUtil.PURPLE_PRIMARY);

            // Category name
            String arrow = collapsed ? "▶" : "▼";
            String title = arrow + " " + category.getDisplayName();
            RenderUtil.drawText(title, x + 5, y + 5, Color.WHITE, true);

            if (!collapsed) {
                for (int i = 0; i < mods.size(); i++) {
                    Module m = mods.get(i);
                    int rowY  = y + HEADER_H + i * MODULE_H;
                    boolean hovered = mx >= x && mx <= x + PANEL_W
                                   && my >= rowY && my <= rowY + MODULE_H;

                    // Row bg
                    Color rowBg = hovered
                            ? new Color(60, 10, 90, 200)
                            : (i % 2 == 0 ? RenderUtil.BG_COLOR : RenderUtil.BG_LIGHT);
                    RenderUtil.drawRect(x, rowY, PANEL_W, MODULE_H, rowBg);

                    // Enabled indicator
                    if (m.isEnabled()) {
                        RenderUtil.drawRect(x, rowY, 2, MODULE_H, RenderUtil.PURPLE_SECONDARY);
                    }

                    // Module name
                    Color nameColor = m.isEnabled() ? RenderUtil.PURPLE_ACCENT : new Color(150, 120, 170);
                    RenderUtil.drawText(m.getName(), x + 7, rowY + 4, nameColor, false);

                    // Toggle pill
                    String state = m.isEnabled() ? "ON" : "OFF";
                    Color stateColor = m.isEnabled() ? new Color(150, 255, 150) : new Color(200, 100, 100);
                    int sw = RenderUtil.getTextWidth(state);
                    RenderUtil.drawText(state, x + PANEL_W - sw - 5, rowY + 4, stateColor, false);
                }
            }
        }
    }
}
