package me.purple.client.modules.hud;

import me.purple.client.module.Module;
import me.purple.client.module.ModuleCategory;
import me.purple.client.utils.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import java.awt.Color;

public class ArmorStatusModule extends Module {
    public ArmorStatusModule() {
        super("Armor Status", "Shows armor durability", ModuleCategory.HUD);
        this.width = 90; this.height = 56;
    }

    @Override
    public void onRender() {
        EntityPlayer p = Minecraft.getMinecraft().thePlayer;
        if (p == null) return;

        ItemStack[] armor = {
            p.inventory.armorInventory[3], // Helmet
            p.inventory.armorInventory[2], // Chestplate
            p.inventory.armorInventory[1], // Leggings
            p.inventory.armorInventory[0]  // Boots
        };
        String[] labels = {"H", "C", "L", "B"};

        int rows = 0;
        for (ItemStack s : armor) if (s != null) rows++;
        if (rows == 0) return;

        int h = rows * 14 + 4;
        this.height = h;
        RenderUtil.drawRect(x, y, width, h, RenderUtil.BG_COLOR);
        RenderUtil.drawBorder(x, y, width, h, 1, RenderUtil.PURPLE_PRIMARY);

        int row = 0;
        for (int i = 0; i < 4; i++) {
            ItemStack stack = armor[i];
            if (stack == null) continue;
            int ry = y + 2 + row * 14;

            // Durability bar color
            int maxDur = stack.getMaxDamage();
            int curDur = maxDur - stack.getItemDamage();
            float pct = maxDur > 0 ? (float) curDur / maxDur : 1f;

            Color barColor;
            if      (pct > 0.6f) barColor = new Color(100, 220, 100);
            else if (pct > 0.3f) barColor = new Color(255, 200, 50);
            else                 barColor = new Color(255, 80, 80);

            // Label
            RenderUtil.drawText(labels[i]+":", x+4, ry+3, RenderUtil.PURPLE_SECONDARY, false);

            // Bar background
            int barX = x + 18, barW = width - 22;
            RenderUtil.drawRect(barX, ry+4, barW, 6, new Color(40, 10, 60));
            // Bar fill
            RenderUtil.drawRect(barX, ry+4, (int)(barW * pct), 6, barColor);
            // Durability text
            String durStr = curDur + "/" + maxDur;
            if (RenderUtil.getTextWidth(durStr) < barW - 2) {
                // only draw if fits
            }
            row++;
        }
    }
}
