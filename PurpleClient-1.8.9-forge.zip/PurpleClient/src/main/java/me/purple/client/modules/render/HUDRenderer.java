package me.purple.client.modules.render;

import me.purple.client.core.PurpleClient;
import me.purple.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Global HUD renderer - registered once, calls onRender() for every enabled module.
 */
public class HUDRenderer {
    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (Minecraft.getMinecraft().currentScreen != null) return; // Hide HUD in GUI

        for (Module m : PurpleClient.getInstance().getModuleManager().getModules()) {
            if (m.isEnabled()) m.onRender();
        }
    }
}
