package me.purple.client.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;
import java.awt.Color;

public class RenderUtil {
    public static final Color PURPLE_PRIMARY   = new Color(138, 43, 226);
    public static final Color PURPLE_SECONDARY = new Color(180, 100, 255);
    public static final Color PURPLE_DARK      = new Color(60,  0, 120);
    public static final Color PURPLE_ACCENT    = new Color(220, 150, 255);
    public static final Color BG_COLOR         = new Color(15, 5, 30, 200);
    public static final Color BG_LIGHT         = new Color(30, 10, 55, 220);

    public static void drawGradientRect(int x,int y,int w,int h,Color top,Color bottom){
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glShadeModel(GL11.GL_SMOOTH);
        GL11.glBegin(GL11.GL_QUADS);
        glColor(top);    GL11.glVertex2d(x,y);
        glColor(top);    GL11.glVertex2d(x+w,y);
        glColor(bottom); GL11.glVertex2d(x+w,y+h);
        glColor(bottom); GL11.glVertex2d(x,y+h);
        GL11.glEnd();
        GL11.glShadeModel(GL11.GL_FLAT);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
    }

    public static void drawRect(int x,int y,int w,int h,Color c){
        Gui.drawRect(x,y,x+w,y+h,c.getRGB());
    }

    public static void drawBorder(int x,int y,int w,int h,int t,Color c){
        drawRect(x,y,w,t,c); drawRect(x,y+h-t,w,t,c);
        drawRect(x,y,t,h,c); drawRect(x+w-t,y,t,h,c);
    }

    public static void drawText(String text,int x,int y,Color c,boolean shadow){
        FontRenderer fr=Minecraft.getMinecraft().fontRendererObj;
        if(shadow) fr.drawStringWithShadow(text,x,y,c.getRGB());
        else fr.drawString(text,x,y,c.getRGB(),false);
    }

    public static int getTextWidth(String t){
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(t);
    }

    private static void glColor(Color c){
        GL11.glColor4f(c.getRed()/255f,c.getGreen()/255f,c.getBlue()/255f,c.getAlpha()/255f);
    }

    public static Color interpolate(Color a,Color b,float t){
        return new Color(
            (int)(a.getRed()+(b.getRed()-a.getRed())*t),
            (int)(a.getGreen()+(b.getGreen()-a.getGreen())*t),
            (int)(a.getBlue()+(b.getBlue()-a.getBlue())*t),
            (int)(a.getAlpha()+(b.getAlpha()-a.getAlpha())*t)
        );
    }
}
