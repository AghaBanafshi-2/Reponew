# Purple Client - Setup Guide

## Prerequisites
- Java 8 JDK
- Forge 1.8.9 MDK (download from files.minecraftforge.net)

## First Time Setup
```bash
# 1. Download Forge 1.8.9 MDK and extract it
# 2. Copy src/ folder into the Forge MDK folder
# 3. Run:
./gradlew setupDecompWorkspace
./gradlew idea   # (or eclipse)

# 4. Build:
./gradlew build
# JAR will be in build/libs/
```

## GitHub Actions (Auto Release)
Push a tag to trigger automatic build & release:
```bash
git tag v1.0.0
git push origin v1.0.0
```
The workflow will build the JAR and create a GitHub Release automatically.
